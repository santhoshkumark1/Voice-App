package com.example.voicesummaryapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import dagger.hilt.android.AndroidEntryPoint
import com.example.voicesummaryapp.ui.NavGraph
import com.example.voicesummaryapp.ui.theme.VoiceTheme
import androidx.navigation.compose.rememberNavController

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VoiceTheme {
                val nav = rememberNavController()
                NavGraph(nav)
            }
        }
    }
}
