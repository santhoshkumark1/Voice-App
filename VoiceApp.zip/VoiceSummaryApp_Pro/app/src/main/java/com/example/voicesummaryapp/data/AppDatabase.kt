package com.example.voicesummaryapp.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Session::class, Transcript::class, Summary::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): Dao
}
