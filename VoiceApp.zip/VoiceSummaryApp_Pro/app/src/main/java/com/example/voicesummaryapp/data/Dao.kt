package com.example.voicesummaryapp.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface Dao {
    @Insert suspend fun insertSession(session: Session): Long
    @Query("SELECT * FROM Session ORDER BY created DESC") fun getSessions(): Flow<List<Session>>

    @Insert suspend fun insertTranscript(t: Transcript)
    @Query("SELECT * FROM Transcript WHERE sessionId=:sid ORDER BY chunkIndex ASC")
    fun getTranscripts(sid: Int): Flow<List<Transcript>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSummary(summary: Summary)
    @Query("SELECT * FROM Summary WHERE sessionId=:sid") fun getSummary(sid: Int): Flow<Summary?>
}
