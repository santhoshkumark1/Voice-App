package com.example.voicesummaryapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Session(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val status: String,
    val created: Long = System.currentTimeMillis()
)

@Entity
data class Transcript(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sessionId: Int,
    val chunkIndex: Int,
    val text: String
)

@Entity
data class Summary(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sessionId: Int,
    val title: String,
    val summary: String,
    val actionItems: String,
    val keyPoints: String
)
