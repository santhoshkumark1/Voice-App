package com.example.voicesummaryapp.repository

import com.example.voicesummaryapp.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow

class MainRepository(private val db: AppDatabase) {

    suspend fun createSession(title: String): Int =
        db.dao().insertSession(Session(title = title, status = "Recording...")).toInt()

    fun getSessions(): Flow<List<Session>> = db.dao().getSessions()

    suspend fun addTranscript(sessionId: Int, chunk: Int, text: String) {
        db.dao().insertTranscript(Transcript(sessionId = sessionId, chunkIndex = chunk, text = text))
    }

    fun getTranscripts(sessionId: Int): Flow<List<Transcript>> =
        db.dao().getTranscripts(sessionId)

    suspend fun generateSummary(sessionId: Int) {
        // Mock: pretend we generated text from transcripts
        delay(1000)
        db.dao().insertSummary(
            Summary(
                sessionId = sessionId,
                title = "Meeting Summary",
                summary = "Discussion covered priorities, blockers, and next steps.",
                actionItems = "- Finalize API design\n- Prepare QA build\n- Schedule stakeholder review",
                keyPoints = "Iterate weekly; prioritize reliability."
            )
        )
    }

    fun getSummary(sessionId: Int): Flow<Summary?> = db.dao().getSummary(sessionId)
}
