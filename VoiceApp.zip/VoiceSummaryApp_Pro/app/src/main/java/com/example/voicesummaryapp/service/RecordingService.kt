package com.example.voicesummaryapp.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.*
import android.os.IBinder
import android.telephony.PhoneStateListener
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import kotlin.math.log10
import kotlin.math.sqrt

class RecordingService : Service() {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var audioRecord: AudioRecord? = null
    private var isRecording = false
    private var paused = false
    private var chunkIndex = 0
    private var silentMs = 0

    private lateinit var telephonyManager: TelephonyManager
    private val phoneListener = object : PhoneStateListener() {
        override fun onCallStateChanged(state: Int, phoneNumber: String?) {
            when (state) {
                TelephonyManager.CALL_STATE_RINGING, TelephonyManager.CALL_STATE_OFFHOOK -> {
                    paused = true
                    updateNotification("Paused - Phone call")
                }
                TelephonyManager.CALL_STATE_IDLE -> {
                    paused = false
                    updateNotification("Recording...")
                }
            }
        }
    }

    private lateinit var audioManager: AudioManager
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT, AudioManager.AUDIOFOCUS_LOSS -> {
                paused = true
                updateNotification("Paused - Audio focus lost")
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                paused = false
                updateNotification("Recording...")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val channelId = "rec_channel"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channelId, "Recording", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, NotificationCompat.Builder(this, channelId)
            .setContentTitle("Voice Summary")
            .setContentText("Recording...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build())

        telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        try { telephonyManager.listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE) } catch (_: SecurityException) { /* ignore */ }

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.requestAudioFocus(
            AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setOnAudioFocusChangeListener(focusListener)
                .setAudioAttributes(AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .build())
                .build()
        )

        startRecording()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(1, NotificationCompat.Builder(this, "rec_channel")
            .setContentTitle("Voice Summary")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build())
    }

    private fun hasLowStorage(): Boolean {
        val dir = getExternalFilesDir(null) ?: filesDir
        val free = dir.usableSpace
        return free < 50 * 1024 * 1024 // <50MB
    }

    private fun startRecording() {
        scope.launch {
            if (hasLowStorage()) {
                updateNotification("Recording stopped - Low storage")
                stopSelf()
                return@launch
            }

            val sampleRate = 16000
            val channelConfig = AudioFormat.CHANNEL_IN_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val minBuffer = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            audioRecord = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sampleRate, channelConfig, audioFormat, minBuffer * 2)
            audioRecord?.startRecording()
            isRecording = true
            paused = false

            val frame = ShortArray(2048)
            val chunkDurationMs = 30_000
            val overlapMs = 2_000
            val bytesPerMs = (sampleRate * 2) / 1000 // 2 bytes per sample mono
            var chunkBytes = 0
            var chunkFile: FileOutputStream? = null
            var chunkEndMs = chunkDurationMs

            fun newChunk(): FileOutputStream {
                val dir = File(getExternalFilesDir(null), "chunks").apply { mkdirs() }
                val file = File(dir, "chunk_%04d.pcm".format(chunkIndex++))
                return FileOutputStream(file)
            }

            chunkFile = newChunk()

            while (isRecording) {
                if (paused) { delay(200); continue }

                val read = audioRecord?.read(frame, 0, frame.size) ?: 0
                if (read <= 0) continue

                // Write to chunk
                val bytes = read * 2
                chunkFile?.write(frame.toByteArray(read))
                chunkBytes += bytes

                // Silence detection over approx 1s windows
                val rms = frameRms(frame, read)
                val frameMs = (read * 1000) / sampleRate
                if (rms < 100) { // simple threshold
                    silentMs += frameMs
                } else {
                    silentMs = 0
                }
                if (silentMs >= 10_000) {
                    updateNotification("No audio detected - Check microphone")
                }

                // handle chunk rollover with 2s overlap
                if (chunkBytes >= bytesPerMs * chunkEndMs) {
                    // keep last 2s in buffer for overlap: here we just close file and start new chunk
                    chunkFile?.flush()
                    chunkFile?.close()
                    // Start next chunk; in a full app we'd prepend last 2s samples
                    chunkFile = newChunk()
                    chunkBytes = bytesPerMs * overlapMs  // logical carry-over
                }
            }

            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
            chunkFile?.flush()
            chunkFile?.close()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Could accept Stop action here
        return START_STICKY
    }

    override fun onDestroy() {
        isRecording = false
        scope.cancel()
        super.onDestroy()
    }
}

private fun ShortArray.toByteArray(len: Int): ByteArray {
    val out = ByteArray(len * 2)
    for (i in 0 until len) {
        val v = this[i].toInt()
        out[i*2] = (v and 0xff).toByte()
        out[i*2+1] = ((v shr 8) and 0xff).toByte()
    }
    return out
}

private fun frameRms(buf: ShortArray, len: Int): Double {
    var sum = 0.0
    for (i in 0 until len) { sum += buf[i]*buf[i].toDouble() }
    return sqrt(sum / len)
}
