package com.example.voicesummaryapp.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.voicesummaryapp.ui.screens.DashboardScreen
import com.example.voicesummaryapp.ui.screens.RecordingScreen
import com.example.voicesummaryapp.ui.screens.SummaryScreen

@Composable
fun NavGraph(nav: NavHostController) {
    NavHost(navController = nav, startDestination = "dashboard") {
        composable("dashboard") { DashboardScreen(nav) }
        composable("recording/{id}") { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id")?.toInt() ?: 0
            RecordingScreen(nav, id)
        }
        composable("summary/{id}") { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id")?.toInt() ?: 0
            SummaryScreen(nav, id)
        }
    }
}
