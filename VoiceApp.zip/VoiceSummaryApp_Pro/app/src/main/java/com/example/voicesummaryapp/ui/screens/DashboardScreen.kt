package com.example.voicesummaryapp.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import kotlinx.coroutines.launch

@Composable
fun DashboardScreen(nav: NavHostController, vm: DashboardVM = hiltViewModel()) {
    val sessions by vm.sessions.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = {
                scope.launch {
                    val id = vm.createNewSession("Meeting " + (100..999).random())
                    nav.navigate("recording/$id")
                }
            }) { Text("+") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
            Text("Meetings", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            sessions.forEach {
                ListItem(
                    headlineText = { Text(it.title) },
                    supportingText = { Text(it.status) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { nav.navigate("summary/${it.id}") }
                )
                Divider()
            }
        }
    }
}
