package com.example.voicesummaryapp.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.navigation.NavHostController
import com.example.voicesummaryapp.service.RecordingService
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun RecordingScreen(nav: NavHostController, sessionId: Int) {
    val ctx = LocalContext.current
    var seconds by remember { mutableStateOf(0) }
    var recording by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        ctx.startForegroundService(Intent(ctx, RecordingService::class.java))
        scope.launch {
            while (recording) {
                delay(1000)
                seconds++
            }
        }
    }

    Scaffold { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Recording Session #$sessionId", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text(String.format("%02d:%02d", seconds / 60, seconds % 60), style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                recording = false
                ctx.stopService(Intent(ctx, RecordingService::class.java))
                nav.navigate("summary/$sessionId")
            }) { Text("Stop & Generate Summary") }
        }
    }
}
