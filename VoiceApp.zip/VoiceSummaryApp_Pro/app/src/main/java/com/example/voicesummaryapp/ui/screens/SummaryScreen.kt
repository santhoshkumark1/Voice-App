package com.example.voicesummaryapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SummaryScreen(nav: NavHostController, sessionId: Int, vm: SummaryVM = hiltViewModel()) {
    val summary by vm.summary.collectAsState(null)
    val loading by vm.loading.collectAsState(false)

    LaunchedEffect(Unit) { vm.loadSummary(sessionId) }

    Scaffold { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
            when {
                loading -> Text("Generating summary...")
                summary != null -> {
                    Text(summary!!.title, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(8.dp))
                    Text(summary!!.summary)
                    Spacer(Modifier.height(12.dp))
                    Text("Action Items", style = MaterialTheme.typography.titleMedium)
                    Text(summary!!.actionItems)
                    Spacer(Modifier.height(12.dp))
                    Text("Key Points", style = MaterialTheme.typography.titleMedium)
                    Text(summary!!.keyPoints)
                }
                else -> Text("No summary yet.")
            }
        }
    }
}
