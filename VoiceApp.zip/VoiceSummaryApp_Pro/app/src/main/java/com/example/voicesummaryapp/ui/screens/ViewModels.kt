package com.example.voicesummaryapp.ui.screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.voicesummaryapp.repository.MainRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardVM @Inject constructor(private val repo: MainRepository) : ViewModel() {
    val sessions = repo.getSessions()
    suspend fun createNewSession(title: String): Int = repo.createSession(title)
}

@HiltViewModel
class SummaryVM @Inject constructor(private val repo: MainRepository) : ViewModel() {
    val summary = MutableStateFlow<com.example.voicesummaryapp.data.Summary?>(null)
    val loading = MutableStateFlow(false)

    fun loadSummary(id: Int) = viewModelScope.launch {
        loading.value = true
        repo.generateSummary(id)
        repo.getSummary(id).collect { s ->
            summary.value = s
            loading.value = false
        }
    }
}
