rootProject.name = "VoiceSummaryApp"
include(":app")
